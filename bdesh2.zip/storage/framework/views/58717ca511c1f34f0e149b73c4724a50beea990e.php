<?php $__env->startSection('content'); ?>
<!-- Header Image or Video -->
<section class="fly-header parallax overlay" style="background-image: url(<?php echo e(asset('public/images/temp/post-8.jpg')); ?>);">
    <div class="fly-header-content">
        <div class="page-subtitle"></div>
        <h1 class="page-title">Donate Now</h1>
    </div>
</section>
<!--/ Header Image or Video -->

<!-- Projects Grid Style -->




<div class="container">
    <div style="margin: 50px;" class="row">
        <?php echo $__env->make('layout.payment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>





<!--/ Projects Grid Style -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>