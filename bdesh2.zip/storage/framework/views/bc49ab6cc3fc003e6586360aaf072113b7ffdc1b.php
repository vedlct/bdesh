<?php $__env->startSection('content'); ?>
    <style>
        p{
            display: inline-block !important;
        }
    </style>
    <!-- Header Image or Video -->
<section class="fly-header parallax overlay" style="background-image: url(<?php echo e(asset('public/images/temp/slide-25.jpg')); ?>);">
        <div class="fly-header-content">
            <div class="page-subtitle"></div>
            <h1 class="page-title">Past Events</h1>
        </div>
    </section>
    <!--/ Header Image or Video -->

<!-- Events -->
<section class="section padding-bottom-50 section gray">
    <div class="section-heading">
        <div class="container">
            <div class="section-subtitle">PAST & UPCOMING EVENTS</div>
            <h2 class="section-title">Events at BDESH</h2>
        </div>
    </div>

    <div class="container">
        <div class="fly-events flex-container">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column">
                <!-- Event -->
                <article class="fly-card fly-event fly-flip-effect" itemscope itemtype="http://schema.org/Event">
                    <div class="boxed flip-front">
                        <a class="event-media js-wave" href="<?php echo e(route('event.singleEvent',[$event->eventId])); ?>" itemprop="url">
                            <img src="<?php echo e(asset('public/Event')); ?>/<?php echo e($event->eventImage); ?>" alt="" itemprop="image" />
                        </a>

                        <div class="event-content">
                            <h3 class="event-title" itemprop="name">
                                <a href="<?php echo e(route('event.singleEvent',[$event->eventId])); ?>"><?php echo e($event->evenntName); ?></a>
                            </h3>

                            <div class="event-location">
                                <a href="#" class="flip-button" itemprop="location"><i class="material-icons">location_on</i><?php echo e($event->eLocation); ?></a>
                                <time class="event-date" datetime="2016-12-12T20:11:00" itemprop="startDate">
                                    <i class="material-icons">query_builder</i>
                                </time>
                            </div>

                            <div class="event-description" itemprop="description">
                                <p>
                                    <?php echo e($event->eventName); ?> Date:<?php echo e($event->startDate); ?> Time : <?php echo e($event->startTime); ?> Special Guest : <?php echo $event->specialGuest; ?>

                                    Tickets : <?php echo e($event->ticketPrice); ?> Contact :<?php echo e($event->contact); ?>

                                </p>
                            </div>

                            <div class="event-footer">
                                <div class="event-buttons">
                                    <a href="<?php echo e(route('event.singleEvent',[$event->eventId])); ?>" class="btn btn-transparent btn-icon-left js-wave" itemprop="url">
                                        <i class="material-icons">arrow_forward</i>Learn More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="boxed flip-back">
                        <div class="card-map" data-placeholder="waiting for map">
                            <div class="google-map"
                                 data-map-zoom="14"
                                 data-map-type="roadmap"
                                 data-map-style="onehope"
                                 data-map-address="1998 Hulman Blvd, Speedway, IN, 46222"
                                 data-map-marker="<?php echo e(asset('public/images/marker.png')); ?>"
                                 data-map-marker-size="[31,46]"
                                 data-map-marker-anchor="[16,46]">
                                <!-- May use data-map-coords="39.795180;-86.234819" instead of data-map-address -->
                            </div>
                        </div>

                        <ul class="card-social">
                            <li><a href="#" class="fa fa-facebook js-wave"></a></li>
                            <li><a href="#" class="fa fa-twitter js-wave"></a></li>
                            <li><a href="#" class="fa fa-instagram js-wave"></a></li>
                            <li><a href="#" class="fa fa-google js-wave"></a></li>
                        </ul>
                    </div>
                </article>
                <!--/ Event -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
                
                
                    
                        
                            
                        

                        
                            
                                
                            

                            
                                
                                
                                    
                                
                            

                            
                                
                                    
                                
                            

                            
                                
                                    
                                        
                                    
                                
                            
                        
                    

                    
                        
                            
                                 
                                 
                                 
                                 
                                 
                                 
                                 
                                
                            
                        

                        
                            
                            
                            
                            
                        
                    
                
                
            
        </div>
    </div>
</section>
<!--/ Events -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>