<?php $__env->startSection('content'); ?>

<!-- Header Image or Video -->
<section class="fly-header parallax overlay" style="background-image: url(<?php echo e(asset('public/images/temp/slide-25.jpg')); ?>);">
    <div class="fly-header-content">
        <div class="page-subtitle"></div>
        <h1 class="page-title">Upcoming Events</h1>
    </div>
</section>
<!--/ Header Image or Video -->

<!-- Events -->
<section class="section padding-bottom-50 section gray">
    <div class="section-heading">
        <div class="container">
            
            <h2 class="section-title">Events are coming soon ! </h2>
        </div>
    </div>


</section>
<!--/ Events -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>