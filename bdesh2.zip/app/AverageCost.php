<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AverageCost extends Model
{
    //
    protected  $table ='averagecost';
    protected $primaryKey='averagecostId';
    public $timestamps =false;
}
