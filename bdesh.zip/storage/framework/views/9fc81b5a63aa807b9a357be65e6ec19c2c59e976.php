<?php echo $__env->make('include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>
<div id="wait" style="display:none;position:fixed;top: 50%;left: 40%;padding:2px;">
    <img src='<?php echo e(url('public/images/pleaseWait-1.gif')); ?>' />
</div>

<?php echo $__env->make('include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>