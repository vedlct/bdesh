<?php $__env->startSection('content'); ?>

    <!-- end row -->
            <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-header mb-5">
                                <div class="row">
                                    <div class="col-6">
                                        <h3>Show Project</h3>

                                    </div>
                                    <div class="col-6">
                                        <a href="<?php echo e(route('project.create')); ?>" class="btn btn-primary pull-right">Add Project</a>
                                    </div>
                                </div>
                            </div>
                            <table id="projectTable" class="table table-bordered " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Location</th>
                                    <th>Goal</th>
                                    <th>Added By</th>
                                    <th width="10%">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($project->pName); ?></td>
                                    <td><?php echo $project->pDescription; ?></td>
                                    <td><?php echo e($project->pLocation); ?></td>
                                    <td><?php echo e($project->pGoal); ?></td>

                                    <td><?php echo e(\App\Http\Controllers\ProjectController::getUserName($project->fkuserId)); ?></td>
                                    <td>
                                        <span class="ml-3"></span>
                                        <a href="<?php echo e(route('project.update',[$project->projectId])); ?>" class="btn btn-info btn-sm" data-panel-id="<?php echo e($project->projectId); ?>" onclick="editProject(this)"><i class="fa fa-edit"></i></a>
                                        <span class="mr-3"></span>
                                        <button class="btn btn-danger btn-sm" data-panel-id="<?php echo e($project->projectId); ?>" onclick="deleteProject(this)"><i class="fa fa-trash"></i></button>
                                    </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>

        <!-- end col -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function deleteProject(x) {
            var id = $(x).data('panel-id');
            $.confirm({
                title: 'Are',
                content: 'Your Sure!',
                buttons: {
                    confirm: function () {
                        $.ajax({
                            type: 'POST',
                            url: "<?php echo route('project.delete'); ?>",
                            cache: false,
                            data: {_token: "<?php echo e(csrf_token()); ?>",'id': id},
                            success: function (data) {
                                $.alert('Project Deleted!');
                                $("#projectTable").load(" #projectTable");
                            }
                        });
                    },
                    cancel: function () {
                        $.alert('Canceled!');
                    }
                }
            });


        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>