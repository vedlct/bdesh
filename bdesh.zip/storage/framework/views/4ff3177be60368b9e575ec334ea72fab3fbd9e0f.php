
<?php echo $__env->make('Admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- modal -->
<div class="modal fade " id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="editEmpBody">

            </div>
        </div>
        <!-- modal-content -->
    </div>
</div>

<!-- modal -->

<?php echo $__env->make('Admin.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>