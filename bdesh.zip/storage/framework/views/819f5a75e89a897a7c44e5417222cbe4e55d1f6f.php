<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(url('public/assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('public/assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('public/assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('public/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- end row -->
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <table id="datatable" class="table table-bordered " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    <tr>
                        <th>First Name</th>
                        <th>LastName</th>
                        <th>email</th>
                        <th>company</th>
                        <th>phone</th>
                        <th>Country</th>
                        <th>City</th>
                        <th>State</th>
                        <th>addr1</th>
                        <th>addr2</th>
                        <th>zip</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <!-- end col -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(url('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script>
        $(document).ready( function () {

            $('#datatable').DataTable({
                processing: true,
                serverSide: true,
                Filter: true,
                stateSave: true,
                type:"POST",
                "ajax":{
                    "url": "<?php echo route('donation.getData'); ?>",
                    "type": "POST",
                    "data":{ _token: "<?php echo e(csrf_token()); ?>"},
                },
                columns: [
                    { data: 'firstName', name: 'donations.firstName'},
                    { data: 'lastName', name: 'donations.lastName'},
                    { data: 'email', name: 'donations.email'},
                    { data: 'country', name: 'donations.country' },
                    { data: 'city', name: 'donations.city' },
                    { data: 'state', name: 'donations.state'},
                    { data: 'company', name: 'donations.company'},
                    { data: 'phone', name: 'donations.phone'},
                    { data: 'addr1', name: 'donations.addr1'},
                    { data: 'addr2', name: 'donations.addr2'},
                    { data: 'zip', name: 'donations.zip'},

                ]
            });
        } );

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>