<?php $__env->startSection('content'); ?>

    <!-- end row -->
            <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-header mb-5">
                                <div class="row">
                                    <div class="col-6">
                                        <h3>Show Event</h3>
i
                                    </div>
                                    <div class="col-6">
                                        <a href="<?php echo e(route('event.create')); ?>" class="btn btn-primary pull-right">Add Project</a>
                                    </div>
                                </div>
                            </div>
                            <table id="projectTable" class="table table-bordered " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Location</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Start Time</th>
                                    <th>place</th>
                                    <th>Special Guest</th>
                                    <th>Ticket Price</th>
                                    <th>Contact</th>
                                    <th width="10%">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($event->eventName); ?></td>
                                    <td><?php echo $event->eLocation; ?></td>
                                    <td><?php echo e($event->startDate); ?></td>
                                    <td><?php echo e($event->EndDate); ?></td>
                                    <td><?php echo e($event->startTime); ?></td>
                                    <td><?php echo e($event->place); ?></td>
                                    <td><?php echo $event->specialGuest; ?></td>
                                    <td><?php echo e($event->ticketPrice); ?></td>
                                    <td><?php echo e($event->contact); ?></td>
                                    <td>
                                        <span class="ml-3"></span>
                                        <a href="<?php echo e(route('event.update',[$event->eventId])); ?>" class="btn btn-info btn-sm" data-panel-id="<?php echo e($event->eventId); ?>" onclick="editProject(this)"><i class="fa fa-edit"></i></a>
                                        <span class="mr-3"></span>
                                        <button class="btn btn-danger btn-sm" data-panel-id="<?php echo e($event->eventId); ?>" onclick="deleteProject(this)"><i class="fa fa-trash"></i></button>
                                    </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>

        <!-- end col -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        function deleteProject(x) {
            var id = $(x).data('panel-id');
            $.confirm({
                title: 'Are',
                content: 'Your Sure!',
                buttons: {
                    confirm: function () {
                        $.ajax({
                            type: 'POST',
                            url: "<?php echo route('event.delete'); ?>",
                            cache: false,
                            data: {_token: "<?php echo e(csrf_token()); ?>",'id': id},
                            success: function (data) {
                                $.alert('Project Deleted!');
                                $("#projectTable").load(" #projectTable");
                            }
                        });
                    },
                    cancel: function () {
                        $.alert('Canceled!');
                    }
                }
            });


        }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>