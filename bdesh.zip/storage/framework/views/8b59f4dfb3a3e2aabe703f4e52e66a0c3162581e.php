<?php $__env->startSection('mainContent'); ?>
    This is Welcome Page
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>