<!DOCTYPE html>
<html lang="zxx" class="no-js page-loader-overflow-hidden">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BDesh Foundation, Inc - Helping the Needy</title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />

    <!-- FontAwesome -->
    <link href="<?php echo e(url('public/css/font-awesome.css')); ?>" media="screen" rel="stylesheet" type="text/css" />

    <!-- Select 2 -->
    <link href="<?php echo e(url('public/css/select2.css')); ?>" media="screen" rel="stylesheet" type="text/css" />

    <!-- Core CSS -->
    <link href="<?php echo e(url('public/css/bootstrap.css')); ?>" media="screen" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('public/css/style.css')); ?>" media="screen" rel="stylesheet" type="text/css" />

    <!-- Animate.css -->
    <link href="<?php echo e(url('public/css/animate.css')); ?>" media="screen" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">

    <!-- Modernizr Library -->
    <script src="<?php echo e(url('public/js/libs/modernizr-3.6.0.min.js')); ?>"></script>
</head>

<body itemscope itemtype="http://schema.org/WebPage">



<!-- Page Loader -->
<div id="pageLoader" class="page-loader">
    <div class="preloader-wheel active">
        <div class="spinner-layer">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div><!--
            --><div class="gap-patch">
                <div class="circle"></div>
            </div><!--
            --><div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>
    </div>
</div>
<!--/ Page Loader -->

<!-- Header -->
<header id="header" class="header" itemscope itemtype="http://schema.org/WPHeader">
    <!-- Navigation Bar -->

    <nav class="navigation-bar" data-become-sticky="600" data-no-placeholder>
        <div class="container">
            <div class="hamburger"><a href="#"></a></div>

            <div class="navigation-bar-flex">
                <!-- Logo TODO: Use 2 images for normal and sticky navigation, or just text -->
                <div class="logo">
                    <a href="<?php echo e(route('home')); ?>">
                        <img class="logo-normal" src="<?php echo e(url('public/images/logo.png')); ?>" alt=""/>
                        <img class="logo-sticky" src="<?php echo e(url('public/images/logo.png')); ?>" alt=""/>
                    </a>
                </div>
                <!--/ Logo -->

                <!-- Dropdown Menu -->
                <ul class="nav-menu clearfix" itemscope itemtype="http://schema.org/SiteNavigationElement">
                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('projects')); ?>">Projects</a></li>
                    <li><a href="<?php echo e(route('rohingya')); ?>">Rohingya</a></li>




                    <li class="">
                        <a href="#">Events </a>
                        <ul>
                            <li><a href="<?php echo e(route('upcomingEvents')); ?>">Upcoming Events</a></li>
                            <li><a href="<?php echo e(route('pastevents')); ?>">Past Events</a></li> 
                        </ul>
                    </li>
                    <li>
                        <a href="#">Media Archive</a>
                        <ul>
                            <li><a href="<?php echo e(route('welfare')); ?>">Children welfare</a></li>
                            <li><a href="<?php echo e(route('healthgallery')); ?>">Health care gallery</a></li>
                            <li><a href="<?php echo e(route('videogallery')); ?>">Video gallery</a></li>
                        </ul>
                    </li>

                    <li><a href="<?php echo e(route('faqs')); ?>">Faqs</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                </ul>
                <!--/ Dropdown Menu -->


            </div>
        </div>
    </nav>

    <!--/ Navigation Bar -->



</header>
<!--/ Header -->