<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RohingyaProject extends Model
{
    //
    protected  $table ='rohingyaproject';
    protected $primaryKey='rohingyaprojectId';
    public $timestamps =false;
}
